@echo off
setlocal
cd /d "%~dp0"
title CrisSteel - ES2
echo ==========================================
echo        CRISSTEEL - ES2
echo ==========================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo Creando el entorno virtual...
    py -3 -m venv .venv
    if errorlevel 1 python -m venv .venv
)
if not exist ".venv\Scripts\python.exe" (
    echo No se pudo crear el entorno virtual.
    pause
    exit /b 1
)
echo Instalando/verificando Django...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo No se pudieron instalar las dependencias.
    pause
    exit /b 1
)
echo Preparando la base de datos...
".venv\Scripts\python.exe" manage.py migrate
if errorlevel 1 (
    echo Hubo un problema con las migraciones.
    pause
    exit /b 1
)
echo Cargando los 40 productos de CrisSteel...
".venv\Scripts\python.exe" manage.py loaddata productos.json
if errorlevel 1 (
    echo Hubo un problema al cargar productos.json.
    pause
    exit /b 1
)
echo Iniciando CrisSteel en http://127.0.0.1:8002/
start "Servidor CrisSteel" cmd /k ""%~dp0.venv\Scripts\python.exe" "%~dp0manage.py" runserver 127.0.0.1:8002"
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:8002/"
endlocal
