from django.shortcuts import get_object_or_404, render

from .imagenes_productos import PRODUCT_IMAGE_DATA
from .models import Producto


CATEGORIAS = {
    "Herramientas eléctricas": ("electricas", "Eléctricas"),
    "Herramientas manuales": ("manuales", "Manuales"),
    "Fijaciones y adhesivos": ("fijaciones", "Fijaciones"),
    "Pinturas y terminaciones": ("pinturas", "Pinturas"),
    "Seguridad industrial": ("seguridad", "Seguridad"),
    "Construcción": ("construccion", "Construcción"),
    "Electricidad": ("electricidad", "Electricidad"),
    "Gasfitería": ("gasfiteria", "Gasfitería"),
}


def preparar_producto(producto):
    """Convierte el objeto ORM en los datos que ya esperaba la interfaz ES1."""
    slug_categoria, nombre_corto = CATEGORIAS.get(
        producto.categoria,
        ("otros", producto.categoria),
    )
    return {
        "id": producto.pk,
        "nombre": producto.nombre,
        "categoria": producto.categoria,
        "precio": producto.precio,
        "stock": producto.stock,
        "descripcion": producto.descripcion,
        "slug_categoria": slug_categoria,
        "categoria_corta": nombre_corto,
        "precio_formateado": f"${producto.precio:,}".replace(",", "."),
        "disponible": producto.stock > 0,
        "imagen_base64": PRODUCT_IMAGE_DATA.get(producto.pk, ""),
    }


def preparar_categorias():
    categorias = []
    for nombre, (slug, nombre_corto) in CATEGORIAS.items():
        cantidad = Producto.objects.filter(categoria=nombre).count()
        if cantidad:
            categorias.append({
                "nombre": nombre_corto,
                "slug": slug,
                "cantidad": cantidad,
            })
    return categorias


def preparar_contexto_catalogo():
    productos_bd = Producto.objects.all().order_by("pk")
    resumen = {
        "total": Producto.objects.count(),
        "con_stock": Producto.objects.filter(stock__gt=0).count(),
        "sin_stock": Producto.objects.filter(stock=0).count(),
        "categorias": Producto.objects.values("categoria").distinct().count(),
    }
    return {
        "productos": [preparar_producto(producto) for producto in productos_bd],
        "resumen": resumen,
        "categorias": preparar_categorias(),
        "origen_datos": "Base de datos SQLite mediante Django ORM",
    }


def lista_productos(request):
    return render(request, "catalogo/lista.html", preparar_contexto_catalogo())


def punto_venta(request):
    contexto = preparar_contexto_catalogo()
    contexto["caja"] = "01"
    return render(request, "catalogo/punto_venta.html", contexto)


def detalle_producto(request, producto_id):
    producto = get_object_or_404(Producto, pk=producto_id)
    return render(
        request,
        "catalogo/detalle.html",
        {"producto": preparar_producto(producto)},
    )
