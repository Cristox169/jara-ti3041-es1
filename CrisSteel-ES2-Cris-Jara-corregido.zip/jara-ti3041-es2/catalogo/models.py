from django.db import models


class Producto(models.Model):
    nombre = models.CharField(max_length=200)
    categoria = models.CharField(max_length=100)
    precio = models.IntegerField()
    stock = models.IntegerField()
    descripcion = models.TextField(blank=True, default="Producto de ferretería CrisSteel.")

    def __str__(self):
        return self.nombre
