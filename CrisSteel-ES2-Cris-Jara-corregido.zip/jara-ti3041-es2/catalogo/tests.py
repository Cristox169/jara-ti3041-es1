from django.test import TestCase
from django.urls import reverse

from .models import Producto


class CatalogoBDTests(TestCase):
    fixtures = ["productos.json"]

    def test_hay_40_productos_en_la_bd(self):
        self.assertEqual(Producto.objects.count(), 40)

    def test_listado_usa_productos_de_la_bd(self):
        response = self.client.get(reverse("catalogo:lista"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Taladro percutor 13 mm")
        self.assertEqual(len(response.context["productos"]), 40)

    def test_resumen_consulta_la_bd(self):
        response = self.client.get(reverse("catalogo:lista"))
        self.assertEqual(response.context["resumen"]["total"], 40)
        self.assertEqual(response.context["resumen"]["con_stock"], 34)
        self.assertEqual(response.context["resumen"]["sin_stock"], 6)
        self.assertEqual(response.context["resumen"]["categorias"], 8)

    def test_detalle_usa_orm(self):
        response = self.client.get(reverse("catalogo:detalle", args=[1]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Taladro percutor 13 mm")

    def test_detalle_inexistente_devuelve_404(self):
        response = self.client.get(reverse("catalogo:detalle", args=[9999]))
        self.assertEqual(response.status_code, 404)

    def test_punto_de_venta_usa_la_bd(self):
        response = self.client.get(reverse("catalogo:punto_venta"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Punto de venta")
        self.assertEqual(len(response.context["productos"]), 40)

    def test_admin_modelo_registrado(self):
        from django.contrib import admin
        self.assertIn(Producto, admin.site._registry)
