from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="Producto",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nombre", models.CharField(max_length=200)),
                ("categoria", models.CharField(max_length=100)),
                ("precio", models.IntegerField()),
                ("stock", models.IntegerField()),
                ("descripcion", models.TextField(blank=True, default="Producto de ferretería CrisSteel.")),
            ],
        ),
    ]
