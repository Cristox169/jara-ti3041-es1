# CrisSteel - Catálogo Online · ES2

Proyecto de Evaluación Sumativa 2 (TI3041), basado en la interfaz creada para ES1.

## Cambios de ES2

- Modelo `catalogo.Producto` con nombre, categoria, precio y stock.
- Migraciones de Django.
- Django Admin con listado, búsqueda y filtro por categoría.
- Fixture `productos.json` con 40 productos.
- El catálogo, el detalle y el punto de venta consultan la base de datos mediante el ORM.
- La interfaz visual de CrisSteel se mantiene y ahora muestra que el inventario proviene de la BD.

## Instalación

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata productos.json
python manage.py createsuperuser
python manage.py runserver
```

El servidor personalizado usa el puerto `8002` por defecto:

`http://127.0.0.1:8002/`

Administración:

`http://127.0.0.1:8002/admin/`

## Si PowerShell bloquea Activate.ps1

También puedes activar el entorno con CMD:

```cmd
.venv\Scripts\activate.bat
```

O ejecutar directamente el Python del entorno sin activarlo:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py loaddata productos.json
.\.venv\Scripts\python.exe manage.py createsuperuser
.\.venv\Scripts\python.exe manage.py runserver
```

## GitHub

Esta carpeta debe utilizarse como un repositorio independiente para ES2, sin copiar el historial Git de ES1.


## Cómo abrir CrisSteel en Windows

1. Abre esta carpeta en Visual Studio Code.
2. Haz doble clic en `iniciar_crissteel.bat`.
3. Espera a que aparezca `Starting development server at http://127.0.0.1:8002/`.
4. Abre en el navegador: `http://127.0.0.1:8002/`
5. Para administrar productos, abre `http://127.0.0.1:8002/admin/` después de crear un superusuario.

El listado principal conserva la interfaz de CrisSteel, pero los productos ahora se obtienen mediante el modelo `Producto` y el ORM de Django desde SQLite. La fixture `productos.json` contiene los 40 productos exigidos para la variante Ferretería.

### Comandos si no quieres usar el archivo BAT

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata productos.json
python manage.py createsuperuser
python manage.py runserver 8002
```
