# CrisFerreterias — Django + MariaDB

Amplía CrisSteel con módulos de ventas, compras, inventario, recursos humanos, remuneraciones, KPI, producción y costos/contabilidad.

## Preparación
1. Instala MariaDB Server y confirma que esté ejecutándose en el puerto 3306.
2. Abre `crear_bd_mariadb.sql` en un cliente MariaDB como administrador y ejecútalo.
3. Cambia `CAMBIAR_ESTA_CLAVE` por una contraseña segura y usa la misma en `config/settings.py`.
4. Ejecuta `iniciar_crisferreterias.bat`.
5. Crea el administrador con `.venv\Scripts\python.exe manage.py createsuperuser`.

Sitio: `http://127.0.0.1:8000/`
Catálogo heredado: `http://127.0.0.1:8000/catalogo/`
Django Admin: `http://127.0.0.1:8000/admin/`

El modelo separa entidades para reducir redundancias. La certificación formal de 5FN exige analizar las dependencias de unión y reglas reales del negocio; este ZIP no se ha ejecutado en tu computador ni validado contra tu instalación MariaDB. No subir a GitHub hasta probar migraciones, consultas, formularios y permisos. El archivo `uso_ia.md` / `uso.deia.md` no se modifica.
