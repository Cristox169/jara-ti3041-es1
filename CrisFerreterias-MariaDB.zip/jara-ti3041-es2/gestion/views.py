from django.db.models import Sum
from django.shortcuts import render
from .models import Producto, Venta, Compra, Empleado, Existencia, OrdenProduccion, LiquidacionSueldo

def dashboard(request):
    context = {
        "productos": Producto.objects.filter(activo=True).count(),
        "ventas": Venta.objects.count(),
        "compras": Compra.objects.count(),
        "empleados": Empleado.objects.filter(estado="activo").count(),
        "existencias": Existencia.objects.aggregate(total=Sum("cantidad"))["total"] or 0,
        "ordenes": OrdenProduccion.objects.exclude(estado__in=["terminada","cancelada"]).count(),
        "liquidaciones": LiquidacionSueldo.objects.filter(pagada=False).count(),
    }
    return render(request, "gestion/dashboard.html", context)
