from django.db import models
from django.core.validators import MinValueValidator

class Categoria(models.Model):
    nombre = models.CharField(max_length=120, unique=True)
    descripcion = models.CharField(max_length=250, blank=True)
    activa = models.BooleanField(default=True)
    def __str__(self): return self.nombre

class Marca(models.Model):
    nombre = models.CharField(max_length=120, unique=True)
    activa = models.BooleanField(default=True)
    def __str__(self): return self.nombre

class UnidadMedida(models.Model):
    codigo = models.CharField(max_length=12, unique=True)
    nombre = models.CharField(max_length=60, unique=True)
    def __str__(self): return self.nombre

class Producto(models.Model):
    sku = models.CharField(max_length=40, unique=True)
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.PROTECT)
    marca = models.ForeignKey(Marca, on_delete=models.SET_NULL, null=True, blank=True)
    unidad = models.ForeignKey(UnidadMedida, on_delete=models.PROTECT)
    precio_venta = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    costo_referencia = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    stock_minimo = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    activo = models.BooleanField(default=True)
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.sku} - {self.nombre}"

class Proveedor(models.Model):
    rut = models.CharField(max_length=15, unique=True)
    razon_social = models.CharField(max_length=180)
    contacto = models.CharField(max_length=120, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    direccion = models.CharField(max_length=220, blank=True)
    activo = models.BooleanField(default=True)
    def __str__(self): return self.razon_social

class ProveedorProducto(models.Model):
    proveedor = models.ForeignKey(Proveedor, on_delete=models.PROTECT)
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    codigo_proveedor = models.CharField(max_length=60, blank=True)
    costo_compra = models.DecimalField(max_digits=12, decimal_places=2)
    plazo_dias = models.PositiveSmallIntegerField(default=0)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["proveedor","producto"], name="uq_prov_producto")]

class Bodega(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=120)
    direccion = models.CharField(max_length=220, blank=True)
    activa = models.BooleanField(default=True)
    def __str__(self): return self.nombre

class Existencia(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    bodega = models.ForeignKey(Bodega, on_delete=models.PROTECT)
    cantidad = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    ubicacion = models.CharField(max_length=80, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["producto","bodega"], name="uq_existencia_prod_bod")]

class Cliente(models.Model):
    rut = models.CharField(max_length=15, unique=True, blank=True)
    nombre = models.CharField(max_length=160)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    direccion = models.CharField(max_length=220, blank=True)
    creado_en = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.nombre

class MedioPago(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=80, unique=True)
    activo = models.BooleanField(default=True)
    def __str__(self): return self.nombre

class Departamento(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    def __str__(self): return self.nombre

class Cargo(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    def __str__(self): return self.nombre

class Empleado(models.Model):
    rut = models.CharField(max_length=15, unique=True)
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=120)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    departamento = models.ForeignKey(Departamento, on_delete=models.PROTECT)
    cargo = models.ForeignKey(Cargo, on_delete=models.PROTECT)
    fecha_contratacion = models.DateField()
    estado = models.CharField(max_length=15, choices=[("activo","Activo"),("licencia","Licencia"),("inactivo","Inactivo")], default="activo")
    def __str__(self): return f"{self.nombres} {self.apellidos}"

class Contrato(models.Model):
    empleado = models.ForeignKey(Empleado, on_delete=models.PROTECT, related_name="contratos")
    tipo = models.CharField(max_length=20, choices=[("indefinido","Indefinido"),("plazo_fijo","Plazo fijo"),("obra","Obra o faena")])
    fecha_inicio = models.DateField()
    fecha_termino = models.DateField(null=True, blank=True)
    sueldo_base = models.DecimalField(max_digits=12, decimal_places=2)
    jornada_horas = models.PositiveSmallIntegerField(default=44)
    vigente = models.BooleanField(default=True)

class KPI(models.Model):
    nombre = models.CharField(max_length=120)
    descripcion = models.CharField(max_length=250, blank=True)
    unidad = models.CharField(max_length=30, blank=True)
    objetivo = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    activo = models.BooleanField(default=True)
    def __str__(self): return self.nombre

class EvaluacionDesempeno(models.Model):
    empleado = models.ForeignKey(Empleado, on_delete=models.PROTECT)
    kpi = models.ForeignKey(KPI, on_delete=models.PROTECT)
    periodo = models.CharField(max_length=20)
    valor_obtenido = models.DecimalField(max_digits=12, decimal_places=2)
    observacion = models.CharField(max_length=250, blank=True)
    fecha = models.DateField()

class LiquidacionSueldo(models.Model):
    empleado = models.ForeignKey(Empleado, on_delete=models.PROTECT)
    periodo = models.CharField(max_length=7)
    sueldo_base = models.DecimalField(max_digits=12, decimal_places=2)
    haberes = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    descuentos = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    liquido_pagar = models.DecimalField(max_digits=12, decimal_places=2)
    fecha_pago = models.DateField(null=True, blank=True)
    pagada = models.BooleanField(default=False)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["empleado","periodo"], name="uq_liquidacion_periodo")]

class Venta(models.Model):
    folio = models.CharField(max_length=30, unique=True)
    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT, null=True, blank=True)
    vendedor = models.ForeignKey(Empleado, on_delete=models.PROTECT)
    fecha = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(max_length=12, choices=[("borrador","Borrador"),("pagada","Pagada"),("anulada","Anulada")], default="borrador")
    observacion = models.CharField(max_length=250, blank=True)
    def __str__(self): return self.folio

class DetalleVenta(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    cantidad = models.DecimalField(max_digits=12, decimal_places=3)
    precio_unitario = models.DecimalField(max_digits=12, decimal_places=2)
    costo_unitario = models.DecimalField(max_digits=12, decimal_places=2)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["venta","producto"], name="uq_detalle_venta_prod")]

class PagoVenta(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.PROTECT, related_name="pagos")
    medio_pago = models.ForeignKey(MedioPago, on_delete=models.PROTECT)
    monto = models.DecimalField(max_digits=12, decimal_places=2)
    fecha = models.DateTimeField(auto_now_add=True)
    referencia = models.CharField(max_length=100, blank=True)

class Compra(models.Model):
    folio = models.CharField(max_length=30, unique=True)
    proveedor = models.ForeignKey(Proveedor, on_delete=models.PROTECT)
    fecha = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(max_length=12, choices=[("borrador","Borrador"),("recibida","Recibida"),("anulada","Anulada")], default="borrador")
    observacion = models.CharField(max_length=250, blank=True)
    def __str__(self): return self.folio

class DetalleCompra(models.Model):
    compra = models.ForeignKey(Compra, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    cantidad = models.DecimalField(max_digits=12, decimal_places=3)
    costo_unitario = models.DecimalField(max_digits=12, decimal_places=2)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["compra","producto"], name="uq_detalle_compra_prod")]

class MovimientoInventario(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    origen = models.ForeignKey(Bodega, on_delete=models.PROTECT, null=True, blank=True, related_name="mov_salida")
    destino = models.ForeignKey(Bodega, on_delete=models.PROTECT, null=True, blank=True, related_name="mov_entrada")
    tipo = models.CharField(max_length=12, choices=[("entrada","Entrada"),("salida","Salida"),("ajuste","Ajuste"),("traslado","Traslado")])
    cantidad = models.DecimalField(max_digits=12, decimal_places=3)
    fecha = models.DateTimeField(auto_now_add=True)
    referencia = models.CharField(max_length=80, blank=True)

class OrdenProduccion(models.Model):
    codigo = models.CharField(max_length=30, unique=True)
    producto_final = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name="ordenes_produccion")
    cantidad_planificada = models.DecimalField(max_digits=12, decimal_places=3)
    cantidad_producida = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    responsable = models.ForeignKey(Empleado, on_delete=models.PROTECT)
    fecha_inicio = models.DateField()
    fecha_termino = models.DateField(null=True, blank=True)
    estado = models.CharField(max_length=12, choices=[("planificada","Planificada"),("en_proceso","En proceso"),("terminada","Terminada"),("cancelada","Cancelada")], default="planificada")

class MaterialOrden(models.Model):
    orden = models.ForeignKey(OrdenProduccion, on_delete=models.CASCADE, related_name="materiales")
    producto_material = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name="usado_en_ordenes")
    cantidad_planificada = models.DecimalField(max_digits=12, decimal_places=3)
    cantidad_utilizada = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["orden","producto_material"], name="uq_material_orden_prod")]

class CentroCosto(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=120)
    activo = models.BooleanField(default=True)
    def __str__(self): return self.nombre

class CuentaContable(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=120)
    tipo = models.CharField(max_length=20, choices=[("ingreso","Ingreso"),("costo","Costo"),("gasto","Gasto"),("activo","Activo"),("pasivo","Pasivo")])
    def __str__(self): return f"{self.codigo} - {self.nombre}"

class AsientoContable(models.Model):
    fecha = models.DateField()
    glosa = models.CharField(max_length=250)
    referencia = models.CharField(max_length=80, blank=True)
    contabilizado = models.BooleanField(default=False)

class LineaAsiento(models.Model):
    asiento = models.ForeignKey(AsientoContable, on_delete=models.CASCADE, related_name="lineas")
    cuenta = models.ForeignKey(CuentaContable, on_delete=models.PROTECT)
    centro_costo = models.ForeignKey(CentroCosto, on_delete=models.PROTECT, null=True, blank=True)
    debe = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    haber = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    descripcion = models.CharField(max_length=250, blank=True)

class ProyectoCosto(models.Model):
    codigo = models.CharField(max_length=30, unique=True)
    nombre = models.CharField(max_length=160)
    descripcion = models.TextField(blank=True)
    fecha_inicio = models.DateField()
    fecha_termino = models.DateField(null=True, blank=True)
    activo = models.BooleanField(default=True)

class CostoProyecto(models.Model):
    proyecto = models.ForeignKey(ProyectoCosto, on_delete=models.PROTECT)
    centro_costo = models.ForeignKey(CentroCosto, on_delete=models.PROTECT)
    cuenta = models.ForeignKey(CuentaContable, on_delete=models.PROTECT)
    fecha = models.DateField()
    monto = models.DecimalField(max_digits=14, decimal_places=2)
    descripcion = models.CharField(max_length=250, blank=True)
