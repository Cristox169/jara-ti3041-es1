from django.contrib import admin
from . import models

@admin.register(models.Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ("sku", "nombre", "categoria", "precio_venta", "activo")
    search_fields = ("sku", "nombre")
    list_filter = ("categoria", "marca", "activo")

for name in [
"Categoria","Marca","UnidadMedida","Proveedor","ProveedorProducto","Bodega","Existencia",
"Cliente","MedioPago","Departamento","Cargo","Empleado","Contrato","KPI","EvaluacionDesempeno",
"LiquidacionSueldo","Venta","DetalleVenta","PagoVenta","Compra","DetalleCompra",
"MovimientoInventario","OrdenProduccion","MaterialOrden","CentroCosto","CuentaContable",
"AsientoContable","LineaAsiento","ProyectoCosto","CostoProyecto"]:
    admin.site.register(getattr(models, name))
