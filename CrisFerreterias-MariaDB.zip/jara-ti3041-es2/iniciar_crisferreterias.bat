@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 python -m venv .venv
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (echo Error instalando dependencias. Revisa MariaDB y mysqlclient.& pause & exit /b 1)
".venv\Scripts\python.exe" manage.py makemigrations gestion
".venv\Scripts\python.exe" manage.py migrate
if errorlevel 1 (echo Fallo la migracion. Revisa la conexion MariaDB.& pause & exit /b 1)
".venv\Scripts\python.exe" manage.py runserver 127.0.0.1:8000
pause
