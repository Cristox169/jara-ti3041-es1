CREATE DATABASE IF NOT EXISTS CrisFerreterias CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'crisferreterias_app'@'localhost' IDENTIFIED BY 'CAMBIAR_ESTA_CLAVE';
GRANT ALL PRIVILEGES ON CrisFerreterias.* TO 'crisferreterias_app'@'localhost';
FLUSH PRIVILEGES;
