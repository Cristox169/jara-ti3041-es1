from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("", include("gestion.urls")),
    path("catalogo/", include("catalogo.urls")),
    path("admin/", admin.site.urls),
]
